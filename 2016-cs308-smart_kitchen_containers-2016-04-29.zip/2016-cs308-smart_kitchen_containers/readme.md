Project Name:
Smart Kitchen Containers

Team Members:
1. Akhil Surya Vamshi 120050067
2. Bhargav Chippada 120050053
3. Jagadeesh Nelaturu 120050055
4. Pranay Dhondi 120050054

Project Description:
Build a platform on which different containers can be placed and replaced. The weights of these containers are to be logged and displayed to the user, along with daily consumption and calorie consumption in an appealing and easily comprehensible manner. If the amount of a commodity goes below a certain level, the user is to be alerted.

